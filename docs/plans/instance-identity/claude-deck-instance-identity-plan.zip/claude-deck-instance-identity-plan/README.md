# Claude Deck Instance Identity Plan

This download contains an implementation plan for adding backend-driven **Instance Identity** and per-instance accent colors to Claude Deck.

## Files

- `IMPLEMENTATION_PLAN.md` — full implementation plan and architecture notes.
- `AGENT_TASKS.md` — split into backend, frontend, Agent Bridge, docs, and QA agent tasks.
- `ACCEPTANCE_CHECKLIST.md` — merge checklist.
- `CODE_SKELETONS.md` — copy/adapt snippets for likely code changes.
- `agent-task-manifest.json` — structured task manifest for local orchestration.

## Recommended workflow

1. Create branch `feature/instance-identity`.
2. Give `AGENT_TASKS.md` Task 1 to a backend agent.
3. Give Task 2 and Task 3 to a frontend UI agent.
4. Give Task 4 to an Agent Bridge agent.
5. Give Task 5 and Task 6 to a docs/QA agent.
6. Use `ACCEPTANCE_CHECKLIST.md` before merging.

## MVP scope

Implement:

- `/status.instance`
- header identity chip
- browser title update
- accent color map
- Agent Bridge session/terminal/dialog labels
- docs and validation

Do not implement yet:

- remote Deck switcher
- multi-instance overview
- settings UI/database persistence
- central proxy
- full theme refactor
