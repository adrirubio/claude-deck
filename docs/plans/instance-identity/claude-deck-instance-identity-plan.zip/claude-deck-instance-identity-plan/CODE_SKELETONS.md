# Code Skeletons: Claude Deck Instance Identity

These snippets are intended to accelerate implementation. Adapt them to the exact local code style and imports.

---

## Backend schema

File: `backend/app/models/schemas.py`

```py
from datetime import datetime
from typing import Literal

InstanceAccent = Literal["blue", "green", "purple", "orange", "red", "pink", "cyan", "slate"]


class InstanceIdentity(BaseModel):
    """Runtime identity for the Claude Deck backend instance."""

    id: str
    name: str
    hostname: str
    short_hostname: str
    accent: InstanceAccent
    started_at: datetime
```

Update status response:

```py
class SystemStatusResponse(BaseModel):
    claude_code_version: Optional[str]
    active_sessions: int
    providers: Optional[Dict[str, AgentProviderStatus]] = None
    instance: Optional[InstanceIdentity] = None
```

---

## Backend service

File: `backend/app/services/instance_identity.py`

```py
"""Runtime Claude Deck instance identity."""

from __future__ import annotations

import hashlib
import logging
import os
import socket
from datetime import datetime, timezone
from functools import lru_cache

from app.models.schemas import InstanceIdentity

LOGGER = logging.getLogger(__name__)

ALLOWED_ACCENTS: tuple[str, ...] = (
    "blue",
    "green",
    "purple",
    "orange",
    "red",
    "pink",
    "cyan",
    "slate",
)

_STARTED_AT = datetime.now(timezone.utc)
_MAX_NAME_LENGTH = 64
_MAX_ID_LENGTH = 64


def _get_hostname() -> str:
    hostname = socket.gethostname().strip()
    return hostname or "unknown-host"


def _short_hostname(hostname: str) -> str:
    short = hostname.split(".", 1)[0].strip()
    return short or hostname or "unknown-host"


def _clean_name(raw_name: str | None, fallback: str) -> str:
    name = (raw_name or "").strip()
    if not name:
        return fallback[:_MAX_NAME_LENGTH]
    return name[:_MAX_NAME_LENGTH]


def _clean_explicit_id(raw_id: str | None) -> str | None:
    value = (raw_id or "").strip()
    if not value:
        return None
    safe = "".join(ch for ch in value if ch.isalnum() or ch in {"-", "_"})
    return safe[:_MAX_ID_LENGTH] or None


def _stable_id(hostname: str, explicit_id: str | None) -> str:
    cleaned = _clean_explicit_id(explicit_id)
    if cleaned:
        return cleaned
    return hashlib.sha256(f"claude-deck:{hostname}".encode("utf-8")).hexdigest()[:12]


def _accent_from_hostname(hostname: str) -> str:
    digest = hashlib.sha256(hostname.encode("utf-8")).digest()
    return ALLOWED_ACCENTS[digest[0] % len(ALLOWED_ACCENTS)]


def _resolve_accent(hostname: str, raw_accent: str | None) -> str:
    accent = (raw_accent or "").strip().lower()
    if not accent:
        return _accent_from_hostname(hostname)
    if accent in ALLOWED_ACCENTS:
        return accent
    LOGGER.warning(
        "Unsupported CLAUDE_DECK_INSTANCE_ACCENT=%r; using hostname-derived accent",
        raw_accent,
    )
    return _accent_from_hostname(hostname)


@lru_cache(maxsize=1)
def get_instance_identity() -> InstanceIdentity:
    hostname = _get_hostname()
    short_hostname = _short_hostname(hostname)
    name = _clean_name(os.getenv("CLAUDE_DECK_INSTANCE_NAME"), short_hostname)

    return InstanceIdentity(
        id=_stable_id(hostname, os.getenv("CLAUDE_DECK_INSTANCE_ID")),
        name=name,
        hostname=hostname,
        short_hostname=short_hostname,
        accent=_resolve_accent(hostname, os.getenv("CLAUDE_DECK_INSTANCE_ACCENT")),
        started_at=_STARTED_AT,
    )
```

---

## Backend status endpoint patch

File: `backend/app/api/v1/status.py`

```py
from app.services.instance_identity import get_instance_identity
```

```py
return SystemStatusResponse(
    claude_code_version=version,
    active_sessions=active_count,
    providers=provider_statuses,
    instance=get_instance_identity(),
)
```

---

## Frontend status types

File: `frontend/src/types/status.ts`

```ts
import type { AgentProviderStatus } from './providers'

export type InstanceAccent =
  | 'blue'
  | 'green'
  | 'purple'
  | 'orange'
  | 'red'
  | 'pink'
  | 'cyan'
  | 'slate'

export interface InstanceIdentity {
  id: string
  name: string
  hostname: string
  short_hostname: string
  accent: InstanceAccent
  started_at?: string
}

export interface SystemStatusResponse {
  claude_code_version: string | null
  active_sessions: number
  providers?: Record<string, AgentProviderStatus>
  instance?: InstanceIdentity
}
```

---

## Frontend accent utility

File: `frontend/src/lib/instanceAccent.ts`

```ts
import type { InstanceAccent } from '@/types/status'

export interface InstanceAccentClasses {
  headerBorder: string
  badge: string
  dot: string
  terminal: string
}

export const DEFAULT_INSTANCE_ACCENT: InstanceAccent = 'blue'

export const INSTANCE_ACCENT_CLASSES: Record<InstanceAccent, InstanceAccentClasses> = {
  blue: {
    headerBorder: 'border-t-blue-500',
    badge: 'border-blue-500/40 bg-blue-500/10 text-blue-700 dark:text-blue-300',
    dot: 'bg-blue-500',
    terminal: 'border-blue-500/40',
  },
  green: {
    headerBorder: 'border-t-green-500',
    badge: 'border-green-500/40 bg-green-500/10 text-green-700 dark:text-green-300',
    dot: 'bg-green-500',
    terminal: 'border-green-500/40',
  },
  purple: {
    headerBorder: 'border-t-purple-500',
    badge: 'border-purple-500/40 bg-purple-500/10 text-purple-700 dark:text-purple-300',
    dot: 'bg-purple-500',
    terminal: 'border-purple-500/40',
  },
  orange: {
    headerBorder: 'border-t-orange-500',
    badge: 'border-orange-500/40 bg-orange-500/10 text-orange-700 dark:text-orange-300',
    dot: 'bg-orange-500',
    terminal: 'border-orange-500/40',
  },
  red: {
    headerBorder: 'border-t-red-500',
    badge: 'border-red-500/40 bg-red-500/10 text-red-700 dark:text-red-300',
    dot: 'bg-red-500',
    terminal: 'border-red-500/40',
  },
  pink: {
    headerBorder: 'border-t-pink-500',
    badge: 'border-pink-500/40 bg-pink-500/10 text-pink-700 dark:text-pink-300',
    dot: 'bg-pink-500',
    terminal: 'border-pink-500/40',
  },
  cyan: {
    headerBorder: 'border-t-cyan-500',
    badge: 'border-cyan-500/40 bg-cyan-500/10 text-cyan-700 dark:text-cyan-300',
    dot: 'bg-cyan-500',
    terminal: 'border-cyan-500/40',
  },
  slate: {
    headerBorder: 'border-t-slate-500',
    badge: 'border-slate-500/40 bg-slate-500/10 text-slate-700 dark:text-slate-300',
    dot: 'bg-slate-500',
    terminal: 'border-slate-500/40',
  },
}

export function getInstanceAccentClasses(accent?: string | null): InstanceAccentClasses {
  if (!accent || !(accent in INSTANCE_ACCENT_CLASSES)) {
    return INSTANCE_ACCENT_CLASSES[DEFAULT_INSTANCE_ACCENT]
  }
  return INSTANCE_ACCENT_CLASSES[accent as InstanceAccent]
}
```

---

## Frontend document title hook

File: `frontend/src/hooks/useInstanceDocumentTitle.ts`

```ts
import { useEffect } from 'react'

import type { InstanceIdentity } from '@/types/status'

const BASE_TITLE = 'Claude Deck'

export function useInstanceDocumentTitle(instance?: InstanceIdentity | null) {
  useEffect(() => {
    document.title = instance?.name ? `${instance.name} · ${BASE_TITLE}` : BASE_TITLE
  }, [instance?.name])
}
```

---

## Header chip snippet

File: `frontend/src/components/layout/Header.tsx`

```tsx
const instance = status?.instance ?? null
const accentClasses = getInstanceAccentClasses(instance?.accent)
useInstanceDocumentTitle(instance)

const instanceTitle = instance
  ? [
      `Claude Deck instance: ${instance.name}`,
      `Hostname: ${instance.hostname}`,
      `Opened from: ${window.location.host}`,
    ].join('\n')
  : 'Claude Deck instance loading'
```

```tsx
<header className={cn('border-b border-t-4 bg-background', accentClasses.headerBorder)}>
```

```tsx
{instance && (
  <Badge
    variant="outline"
    className={cn('gap-1 text-xs max-w-[12rem] truncate', accentClasses.badge)}
    title={instanceTitle}
  >
    <Server className="h-3 w-3 shrink-0" />
    <span className={cn('h-2 w-2 rounded-full shrink-0', accentClasses.dot)} />
    <span className="truncate">{instance.name}</span>
  </Badge>
)}
```

---

## Agent Bridge session card snippet

File: `frontend/src/features/cc-bridge/SessionCard.tsx`

```tsx
<p
  className="text-xs text-muted-foreground mt-0.5 truncate"
  title={instance ? `${instance.name} · ${session.tmux_target}` : session.tmux_target}
>
  {instance ? `${instance.name} · ` : ''}tmux: {session.tmux_target}
</p>
```

---

## Terminal footer snippet

File: `frontend/src/features/cc-bridge/TerminalView.tsx`

```tsx
<span
  className="text-xs text-muted-foreground truncate max-w-[18rem]"
  title={instance ? `${readOnly ? 'Read-only' : 'Interactive'} on ${instance.name} (${instance.hostname}) · ${target}` : target ?? undefined}
>
  {instance ? `${readOnly ? 'Read-only' : 'Interactive'} on ${instance.name}` : readOnly ? 'Read-only' : 'Interactive'}
</span>
```

---

## Kill dialog copy snippet

File: `frontend/src/features/cc-bridge/KillSessionDialog.tsx`

```tsx
<AlertDialogTitle>
  Kill {session?.session_name ?? 'session'}{instance ? ` on ${instance.name}` : ''}?
</AlertDialogTitle>

<AlertDialogDescription>
  This will terminate tmux target {session?.tmux_target}
  {instance ? ` on hostname ${instance.hostname}` : ''}.
</AlertDialogDescription>
```
