# Acceptance Checklist: Claude Deck Instance Identity

Use this checklist before merging.

## Backend API

- [ ] `/status` includes an `instance` object.
- [ ] `instance.id` is present.
- [ ] `instance.name` is present.
- [ ] `instance.hostname` is present.
- [ ] `instance.short_hostname` is present.
- [ ] `instance.accent` is one of: `blue`, `green`, `purple`, `orange`, `red`, `pink`, `cyan`, `slate`.
- [ ] `instance.started_at` is present and ISO-serializable.
- [ ] With no env vars, backend uses hostname-derived defaults.
- [ ] `CLAUDE_DECK_INSTANCE_NAME` overrides `instance.name`.
- [ ] `CLAUDE_DECK_INSTANCE_ACCENT` overrides `instance.accent` when valid.
- [ ] Invalid `CLAUDE_DECK_INSTANCE_ACCENT` falls back without crashing.
- [ ] `CLAUDE_DECK_INSTANCE_ID` overrides `instance.id` safely.
- [ ] No raw MAC address, raw machine-id, auth token, or secret config appears in `/status`.

## Frontend header

- [ ] Header still shows `Claude Deck` as app title.
- [ ] Header shows an instance chip when `status.instance` exists.
- [ ] Instance chip displays `instance.name`.
- [ ] Instance chip tooltip/title includes `instance.hostname`.
- [ ] Instance chip tooltip/title includes `window.location.host`.
- [ ] Header has an accent-colored top border.
- [ ] Accent is visible in light mode.
- [ ] Accent is visible in dark mode.
- [ ] Provider badges still render.
- [ ] Active session count badge still renders.
- [ ] Theme toggle still works.
- [ ] Layout does not overflow badly on normal laptop widths.

## Browser title

- [ ] Before status loads, title is `Claude Deck` or existing fallback.
- [ ] After status loads, title is `<instance name> · Claude Deck`.
- [ ] Two different Deck windows show different OS/browser switcher titles when configured differently.

## Agent Bridge

- [ ] Session cards show instance name near the `tmux` target/project metadata.
- [ ] Terminal footer shows instance name when attached.
- [ ] Terminal footer makes read-only vs interactive mode clear.
- [ ] Interactive mode text includes the instance name.
- [ ] Kill session dialog title includes instance name.
- [ ] Kill session dialog body includes hostname or target instance detail.
- [ ] Kill/spawn/resume/fork toasts include instance name where useful.
- [ ] Existing attach/detach behavior still works.
- [ ] Existing fullscreen behavior still works.
- [ ] Existing close terminal behavior still works.

## Build/test

- [ ] `cd frontend && npm run lint` passes.
- [ ] `cd frontend && npm run build` passes.
- [ ] `cd backend && python -m pytest` passes, if backend tests are configured.
- [ ] `./scripts/build.sh` passes, if used as the release check.

## Multi-machine smoke test

- [ ] Machine A with `Studio Mac / blue` displays `Studio Mac` and blue accent.
- [ ] Machine B with `Linux Box / green` displays `Linux Box` and green accent.
- [ ] Both windows can be opened from a third machine.
- [ ] Browser title, header chip, Agent Bridge cards, and terminal footer all match the correct backend.

## Scope control

- [ ] No central proxy was added.
- [ ] No database migration was added for this MVP.
- [ ] No full theme system refactor was added.
- [ ] No arbitrary user-supplied CSS/classes are rendered.
- [ ] `instance` is optional on the frontend for compatibility.
