# Agent Task Pack: Claude Deck Instance Identity

Use these as direct prompts/tasks for local coding agents. Each task has clear ownership and acceptance criteria.

---

## Task 0 — Integration conductor

**Role:** Coordinate branch, review PRs/patches, and prevent scope creep.

**Goal:** Ship backend-driven Instance Identity without turning it into a full theming/settings refactor.

**Instructions:**

1. Create branch `feature/instance-identity`.
2. Assign tasks in this file to agents.
3. Make sure every agent uses the same API shape and names.
4. Keep accent separate from light/dark theme.
5. Keep `instance` optional on the frontend.
6. Run final validation checklist.

**Definition of done:**

- All acceptance criteria in `ACCEPTANCE_CHECKLIST.md` pass.
- No agent added a remote proxy, database migration, or settings UI in MVP.

---

## Task 1 — Backend instance identity

**Owner:** Backend agent  
**Files:**

- `backend/app/models/schemas.py`
- `backend/app/services/instance_identity.py`
- `backend/app/api/v1/status.py`
- backend tests if present

**Goal:** Expose runtime backend identity in the existing status response.

**API shape:**

```json
"instance": {
  "id": "studio-mac",
  "name": "Studio Mac",
  "hostname": "studio-mac.local",
  "short_hostname": "studio-mac",
  "accent": "blue",
  "started_at": "2026-06-11T15:21:43.120000Z"
}
```

**Steps:**

1. Add `InstanceIdentity` schema.
2. Add optional `instance` to `SystemStatusResponse`.
3. Create `backend/app/services/instance_identity.py`.
4. Resolve env vars:
   - `CLAUDE_DECK_INSTANCE_NAME`
   - `CLAUDE_DECK_INSTANCE_ACCENT`
   - `CLAUDE_DECK_INSTANCE_ID`
5. Fallback to hostname-derived `name`, `id`, and `accent` when env vars are missing.
6. Validate accent against:
   - `blue`
   - `green`
   - `purple`
   - `orange`
   - `red`
   - `pink`
   - `cyan`
   - `slate`
7. Update `/status` to include `instance=get_instance_identity()`.
8. Add/adjust tests.

**Acceptance criteria:**

- `/status.instance` exists.
- Env overrides work.
- Invalid accent does not crash.
- No raw MAC address or machine-id is exposed.
- Backend tests pass if present.

---

## Task 2 — Frontend status types, document title, and accent utility

**Owner:** Frontend foundation agent  
**Files:**

- `frontend/src/types/status.ts`
- `frontend/src/hooks/useSystemStatus.ts`
- `frontend/src/hooks/useInstanceDocumentTitle.ts`
- `frontend/src/lib/instanceAccent.ts`

**Goal:** Make instance identity available to UI components.

**Steps:**

1. Add `InstanceAccent` type.
2. Add `InstanceIdentity` interface.
3. Add optional `instance?: InstanceIdentity` to `SystemStatusResponse`.
4. Update `useSystemStatus` returned shape to include `instance: InstanceIdentity | null`.
5. Add `useInstanceDocumentTitle(instance)` hook.
6. Add `getInstanceAccentClasses(accent)` utility with static Tailwind class map.

**Important:** Do not generate Tailwind class names dynamically.

**Acceptance criteria:**

- TypeScript compiles.
- Hook returns `instance` without breaking existing consumers.
- `document.title` can be updated by consumers.
- All supported accents have class mappings.

---

## Task 3 — Header instance chip

**Owner:** Frontend UI agent  
**Files:**

- `frontend/src/components/layout/Header.tsx`

**Goal:** Make the current Claude Deck instance obvious in the top bar.

**Steps:**

1. Read `instance` from existing `useSystemStatus()` call.
2. Call `useInstanceDocumentTitle(instance)`.
3. Add top border accent to header.
4. Add instance badge/chip before provider badges.
5. Badge label should be `instance.name`.
6. Badge tooltip should include:
   - display name
   - hostname
   - `window.location.host`
7. Keep the product title `Claude Deck` unchanged.
8. Keep `ThemeToggle` behavior unchanged.

**Acceptance criteria:**

- Header shows `Studio Mac` when backend returns that name.
- Browser title becomes `Studio Mac · Claude Deck`.
- Accent is visible in both light and dark modes.
- Existing provider/version/active session badges still work.

---

## Task 4 — Agent Bridge instance labels

**Owner:** Agent Bridge frontend agent  
**Files:**

- `frontend/src/features/cc-bridge/CCBridgePage.tsx`
- `frontend/src/features/cc-bridge/SessionList.tsx`
- `frontend/src/features/cc-bridge/SessionCard.tsx`
- `frontend/src/features/cc-bridge/TerminalView.tsx`
- `frontend/src/features/cc-bridge/KillSessionDialog.tsx`
- toast-related files if kill/spawn toasts are elsewhere

**Goal:** Prevent wrong-machine mistakes during terminal/session operations.

**Steps:**

1. In `CCBridgePage`, call `useSystemStatus()` and derive `instance`.
2. Pass `instance` to `SessionList`, `TerminalView`, and `KillSessionDialog`.
3. In `SessionList`, pass `instance` to `SessionCard`.
4. In `SessionCard`, display `instance.name` next to the existing `tmux` target line.
5. In `TerminalView`, show `Read-only on <name>` or `Interactive on <name>` in the footer.
6. In `KillSessionDialog`, include instance name and hostname in title/body.
7. Update success/error toasts for kill/spawn/resume/fork to include `on <instance.name>` where useful.

**Acceptance criteria:**

- Session cards identify the backend instance.
- Terminal panes identify the backend instance while attached.
- Interactive mode clearly says which instance is interactive.
- Kill confirmation names the instance and hostname.
- Existing Agent Bridge functionality remains unchanged.

---

## Task 5 — Documentation and examples

**Owner:** Docs/QA agent  
**Files:**

- `README.md`
- `.env.example` if present
- docs page if desired

**Goal:** Document how to name/color Claude Deck instances.

**Steps:**

1. Add a README section near Development or Agent Bridge usage.
2. Include examples for multiple machines.
3. Document supported accents.
4. Mention where the name appears:
   - header
   - browser title
   - Agent Bridge session cards
   - terminal pane footer
   - destructive confirmations
5. Add env vars to `.env.example` if the file exists.

**Acceptance criteria:**

- A user can configure two machines from docs alone.
- Docs mention that env vars are optional.
- Docs state that hostname is fallback.

---

## Task 6 — QA and final review

**Owner:** QA agent  
**Goal:** Verify implementation against real local usage.

**Commands:**

```bash
cd frontend
npm run lint
npm run build
```

```bash
cd backend
python -m pytest
```

If backend tests are not configured, run the project manually and test `/status` via API docs/curl.

**Manual scenarios:**

1. No env vars.
2. Valid env vars.
3. Invalid accent.
4. Two machines/two windows.
5. Agent Bridge attach/detach.
6. Interactive mode.
7. Kill confirmation.
8. Dark/light mode toggle.

**Acceptance criteria:**

- All checklist items pass.
- No unrelated UI regressions.
- No sensitive local identifiers exposed.
